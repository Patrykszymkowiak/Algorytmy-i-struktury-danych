﻿using System;

namespace ProblemPlecakowy
{
    class Program
    {
        static void Main(string[] args)
        {
            int elements, bagWeight = 0;
            int maxValue  = new int();
            maxValue = 0;
            int sum = new int();
            int count = 1;
            Console.WriteLine("Podaj liczbe elementow");
            int.TryParse(Console.ReadLine(), out elements);
            int[] tWeight = new int[elements];
            int[] tValue = new int[elements];
            for (int i = 0; i<elements; i++)
            {
                Console.WriteLine("Podaj wage elementu {0}:", count);
                tWeight[i] = int.Parse(Console.ReadLine());
                count++;
            }
            count = 1;
            for (int i = 0; i < elements; i++)
            {
                Console.WriteLine("Podaj wartosc elementu {0}:", count);
                tValue[i] = int.Parse(Console.ReadLine());
                count++;
            }
            Console.WriteLine("Podaj wage w plecaku");
            int.TryParse(Console.ReadLine(), out bagWeight);
            count = 0;
            int maxBagWeight = bagWeight;
            while(bagWeight>=0)
            {
                for (int i = 0; i < elements; i++)
                {
                    if (tValue[i] > maxValue)
                    {
                        maxValue = tValue[i];
                        count++;
                    }
                }
                if (tWeight[count] <= bagWeight)
                {
                    bagWeight = bagWeight - tWeight[count];
                    tValue[count] = 0;
                    tWeight[count] = 0;
                    count = 0;
                }
                else if(tWeight[count] > bagWeight)
                {
                    tValue[count] = 0;
                    tWeight[count] = 0;
                    count = 0;
                }
                for(int i=0; i<elements; i++)
                {
                    sum = tWeight[i] + sum;
                }
                if(sum==0)
                {
                    break;
                }
            }
            Console.WriteLine("Pozostala waga w plecaku: {0}", bagWeight);
            Console.ReadKey();
        }
    }
}
